use std::{
    fs::{self, File},
    ops::RangeInclusive,
    path::PathBuf,
};

use clap::{Parser, ValueHint};
use log::{debug, error, info};
use mismatchfinder::{
    bamreader::self,
    output,
};
use rust_htslib::bam;
use simple_logger::SimpleLogger;

/// Reference to be used for analysis. (should only be relevant for crams)
// #[clap(short='T', long="reference", value_hint = ValueHint::FilePath)]
// reference_file: PathBuf,

#[derive(Parser, Debug)]
#[clap(author, version, about, long_about = None)]
struct Options {
    /// Output folder to write files to
    #[clap(short='o', long="output", value_hint = ValueHint::FilePath)]
    output_folder: PathBuf,

    /// Bed file for genomic regions to ignore in the analysis. White list bed file regions overwrite black list regions
    #[clap(long="blacklist_bed", value_hint = ValueHint::FilePath)]
    blacklist_file: Option<PathBuf>,

    /// Bed file for genomic regions to include in the analysis. White list bed file regions overwrite black list regions [default: all regions]
    #[clap(long="whitelist_bed", value_hint = ValueHint::FilePath)]
    whitelist_file: Option<PathBuf>,

    /// File to read germline information from default is an echtvar file
    #[clap(long="germline_file", value_hint = ValueHint::FilePath)]
    germline_file: Option<PathBuf>,

    /// Mimimum mapping quality for a read to be considered
    #[clap(
        short = 'q',
        long = "minimum_mapping_quality",
        value_parser,
        default_value_t = 20
    )]
    min_mapping_quality: u8,

    /// Mimimum base quality of the mismatch (BQ is summed for a readpair if reads agree)
    #[clap(
        short = 'Q',
        long = "minimum_base_quality",
        value_parser,
        default_value_t = 65
    )]
    min_base_quality: u8,

    /// Maximum mismatches we allow in the read
    #[clap(
        long = "maximum_edit_distance_per_read",
        value_parser,
        default_value_t = 15
    )]
    max_edit_distance_per_read: i8,

    /// Mimimum mismatches we require in the read
    #[clap(
        long = "minimum_edit_distance_per_read",
        value_parser,
        default_value_t = 1
    )]
    min_edit_distance_per_read: i8,

    /// Mimimum average base quality of the read
    #[clap(
        long = "minimum_average_base_quality",
        value_parser,
        default_value_t = 25.
    )]
    min_average_base_quality: f32,

    /// Length of fragments to be considered in the analysis
    #[clap(long = "fragment_length_intervals", value_parser, action = clap::ArgAction::Append, multiple_values=true, default_values(&["100-150", "250-325"]))]
    fragment_length_intervals: Vec<String>,

    /// only use the overlap of the two reads
    #[clap(long = "only_overlaps", value_parser, default_value_t = false , action = clap::ArgAction::SetTrue)]
    only_overlaps: bool,

    /// only analyse mismatches if the read pair agree (does not restrict to only overlap)
    #[clap(long = "strict_overlaps", value_parser, default_value_t = false , action = clap::ArgAction::SetTrue)]
    strict_overlap: bool,

    /// overwrite previous results
    #[clap(long, value_parser, default_value_t = false , action = clap::ArgAction::SetTrue)]
    overwrite: bool,

    /// Bams to analyse
    #[clap(value_hint = ValueHint::FilePath, action = clap::ArgAction::Append, multiple_values=true)]
    bams: Vec<PathBuf>,
}

fn main() {
    let cli = Options::parse();

    SimpleLogger::new()
        .with_level(log::LevelFilter::Info)
        .env()
        .init()
        .unwrap();

    //check if we can write to the output folder, or if it doesnt exist yet, if we can create it
    match fs::create_dir_all(&cli.output_folder) {
        Ok(_) => { // we are happy and dont worry
        }
        Err(e) => panic!("Couldnt open output folder: {}", e),
    };

    // make this an option with lapper being default
    let lapper = true;
    //create white list object
    let bed;
    if lapper {
        // obviously this heavily depends on the network speed etc, but this was run multiple time to ensure a representative sampling
        // real	11m30.015s, 11m50.762s, 12m14.666s, 11m22.795s
        // user	8m1.104s, 8m3.983s, 7m57.696s, 7m35.625s
        // sys	0m38.480s, 0m42.985s, 0m38.536s, 0m26.196s
        bed = match cli.whitelist_file {
            Some(file) => {
                debug!(
                    "Parsing bed file {} as white list to lapper object",
                    file.display()
                );
                Some(bamreader::filter::region::BedObject::lapper_from_bed(file))
            }
            None => {
                debug!("No white list bed file detected, including all reads in analysis");
                None
            }
        };
    } else {
        // real	12m18.631s, 11m57.539s, 12m48.091s, 13m0.463s, 12m13.922s
        // user	8m17.179s, 7m54.323s, 8m21.796s, 8m15.832s, 8m2.991s
        // sys	0m52.488s, 0m32.826s, 0m42.453s, 0m47.496s, 0m34.951s
        bed = match cli.whitelist_file {
            Some(file) => {
                debug!(
                    "Parsing bed file {} as white list to lapper object",
                    file.display()
                );
                Some(bamreader::filter::region::BedObject::interval_tree_from_bed(file))
            }
            None => {
                debug!("No white list bed file detected, including all reads in analysis");
                None
            }
        };
    }

    let mut gnomad = match cli.germline_file {
        Some(file) => Some(
            bamreader::filter::germline::GermlineResource::load_echtvars_file(
                file.to_str().unwrap(),
            ),
        ),
        None => None,
    };

    let mut fragment_length_intervals: Vec<RangeInclusive<i64>> = Vec::new();

    for ivl in cli.fragment_length_intervals {
        let ivl: Vec<&str> = ivl.split("-").collect();
        if ivl.len() != 2 {
            panic!("We require the fragment length intervals to be in the shape of <x>-<y>")
        } else {
            //try to convert the intervals into numerics
            let start = match ivl[0].parse::<i64>() {
                Ok(v) => v,
                Err(_) => panic!("Could not convert start value to numeric"),
            };
            let end = match ivl[1].parse::<i64>() {
                Ok(v) => v,
                Err(_) => panic!("Could not convert end value to numeric"),
            };
            fragment_length_intervals.push(start..=end);
        }
    }

    for bam in cli.bams {
        //prepare file names
        let base = bam.file_stem().unwrap();
        let mut bam = bam::Reader::from_path(&bam).unwrap();
        let vcf_file = cli
            .output_folder
            .join(format!("{}_bamsites.vcf.gz", base.to_str().unwrap()));

        if !vcf_file.exists() || cli.overwrite {
            //we create the file here, so that we can easier run the analysis in parallel
            File::create(&vcf_file).expect("Could not create vcf file");

            let mut mismatches = mismatchfinder::bamreader::find_mismatches(
                &mut bam,
                &bed,
                &fragment_length_intervals,
                cli.min_edit_distance_per_read,
                cli.max_edit_distance_per_read,
                cli.min_mapping_quality,
                cli.min_average_base_quality,
                cli.min_base_quality,
                cli.only_overlaps,
                cli.strict_overlap,
            );
            info!("Found {} mismatches ", mismatches.len());

            // if we have a germline resource we filter them out
            if let Some(ref mut g) = gnomad {
                // we could potentially only annotate the germline status,
                // but then we still have to write about a million germline vars
                g.filter_germline_cooccurance(&mut mismatches);

                info!("Found {} somatic mismatches", mismatches.len());
            }

            match output::write_vcf(&mismatches, vcf_file, true, true) {
                Err(_) => error!("Could not write mismatch file"),
                Ok(_) => {}
            }
        }
    }
}