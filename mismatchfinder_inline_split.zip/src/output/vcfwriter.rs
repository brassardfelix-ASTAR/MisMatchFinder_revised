##source=MisMatchFinder
##FILTER=<ID=PASS,Description=\"Mismatch of high quality\">
##INFO=<ID=MULTI,Number=1,Type=Integer,Description=\"Number of reads supporting the mismatch\">
##INFO=<ID=SOMATIC,Number=0,Type=Flag,Description=\"This variant is somatic after germline check\">
##INFO=<ID=FRAG_LEN,Number=1,Type=Integer,Description=\"Length of the fragment\">
##INFO=<ID=STRAND,Number=1,Type=String,Description=\"Read orientation (F/R)\">
##INFO=<ID=POS_IN_READ,Number=1,Type=Integer,Description=\"Position of mismatch in read\">
##INFO=<ID=REGION_TAG,Number=1,Type=String,Description=\"Region tag from BED file\">
##INFO=<ID=OVERLAP,Number=1,Type=String,Description=\"Whether reads overlap\">
##INFO=<ID=AGREE,Number=1,Type=String,Description=\"Whether reads agree on mismatch\">
##INFO=<ID=MAPQ,Number=1,Type=String,Description=\"Mapping quality range\">
##INFO=<ID=NM,Number=1,Type=String,Description=\"Edit distance range\">
##INFO=<ID=BQ,Number=1,Type=Integer,Description=\"Base quality of mismatch\">
#CHROM\tPOS\tID\tREF\tALT\tQUAL\tFILTER\tINFO\n";

pub fn write_vcf(
    mismatches: &BTreeMap<Mismatch, MismatchMeta>,
    file: PathBuf,
    include_small_vars: bool,
    somatic: bool,
) -> std::io::Result<()> {
    let mut vcf_fh = File::create(file)?;
    let mut writer = BGZFWriter::new(&mut vcf_fh, flate2::Compression::default());

    writer.write_all(VCF_HEADER)?;

    for (mm, meta) in mismatches {
        let info = mm.to_vcf_info(
            Some(meta.rp_names.len()),
            meta.overlap,
            meta.agree,
            Some((meta.mapq[0], *meta.mapq.last().unwrap())),
            Some(meta.frag_len.len()),
            Some((meta.nm[0], *meta.nm.last().unwrap())),
            Some(mm.quality),
            mm.pos_in_read,
        );

        let ref_str = std::str::from_utf8(&mm.reference).unwrap();
        let alt_str = std::str::from_utf8(&mm.alternative).unwrap();

        let line = format!(
            "{}\t{}\t.\t{}\t{}\t{}\tPASS\t{}{}",
            mm.chromosome,
            mm.position,
            ref_str,
            alt_str,
            mm.quality,
            info,
            if somatic { ";SOMATIC\n" } else { "\n" }
        );

        writer.write_all(line.as_bytes())?;
    }

    writer.close()?;
    Ok(())
}